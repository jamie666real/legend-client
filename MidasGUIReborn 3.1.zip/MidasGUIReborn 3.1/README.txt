############################################################
##                                                        ##
##              Thank you for download!                   ##
##                                                        ##
############################################################

//
// MADE BY Clarity Creation
//


Drag & Drop all configs to your plugin folder

Plugins required:

- DeluxeMenus
- ItemsAdder / Oraxen / Nexo
- PlaceholderAPI

Since ItemsAdder and Oraxen use different unicode characters, different configs for DeluxeMenus are used accordingly. They can be found in the folders of the same name (ItemsAdder / Oraxen / Nexo).

PlaceholderAPI expansions required: 

- Player
- Statistics

To download it just use these commands:

/papi ecloud download Player
/papi ecloud download Statistics 


Please, join to our Discord community

https://discord.gg/YdFP7P2dgR
